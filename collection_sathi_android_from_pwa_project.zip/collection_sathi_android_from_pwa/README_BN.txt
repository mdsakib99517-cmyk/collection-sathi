কালেকশন সাথী — Android APK তৈরির প্রজেক্ট
================================================

এই প্রজেক্টটি আপনার দেওয়া collection_sathi_installable_package.zip থেকে তৈরি।
এর মূল অ্যাপ index.html এবং সঙ্গে manifest, service worker ও আইকন রাখা হয়েছে।

গুরুত্বপূর্ণ:
• এটি Android Studio/AndroidIDE-তে খোলার জন্য সোর্স প্রজেক্ট; তৈরি করা APK নয়।
• এই পরিবেশে Android SDK/Gradle build tool নেই, তাই APK তৈরি ও পরীক্ষা করা সম্ভব হয়নি।
• অ্যাপটি WebView-এর ভিতরে index.html চালায়। JavaScript ও DOM storage চালু আছে।
• হিসাবের তথ্য WebView-এর local storage-এ থাকবে। অ্যাপের ডেটা মুছে ফেললে বা অ্যাপ আনইনস্টল করলে হিসাব হারাতে পারেন—নিয়মিত অ্যাপের ব্যাকআপ/এক্সপোর্ট ব্যবহার করুন।
• PWA service worker সাধারণ file:// WebView-এ সচরাচর চালু হয় না; APK-তে HTML/আইকন স্থানীয় asset হিসেবে থাকায় মূল অফলাইন পেজ খোলার জন্য আলাদা ইন্টারনেট অনুমতি রাখা হয়নি।
• এই প্রজেক্টে APK তৈরির আগে Android SDK এবং উপযুক্ত Gradle/Android plugin সেটআপ লাগবে।

ফাইল:
app/src/main/assets/index.html — অ্যাপের মূল পৃষ্ঠা
app/src/main/assets/manifest.webmanifest — PWA manifest
app/src/main/assets/sw.js — PWA service worker
app/src/main/java/com/collectionsathi/app/MainActivity.java — Android WebView wrapper

নির্মাণের পরামর্শ:
1. ZIP-টি Extract করুন।
2. AndroidIDE বা Android Studio-তে extracted `collection_sathi_android_from_pwa` ফোল্ডারটি Open করুন।
3. Android SDK/Gradle সেটআপ শেষ করে Gradle sync দিন।
4. Build menu থেকে APK তৈরি করুন।
5. ফোনে ইনস্টল করার আগে APK-টি পরীক্ষা করুন এবং প্রথমে অল্প কিছু ডেমো তথ্য দিয়ে ব্যাকআপ/রিস্টোর যাচাই করুন।

নিরাপত্তা:
AndroidIDE-এর মতো তৃতীয়-পক্ষ build tool ব্যবহার করলে শুধু বিশ্বস্ত/অফিশিয়াল উৎস থেকে নিন। পুরোনো বা অরক্ষণাবেক্ষিত অ্যাপ ব্যবহার ঝুঁকিপূর্ণ হতে পারে।
